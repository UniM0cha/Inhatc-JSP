package mall;

public class OrderVO {
	private int oid;
	private String id;
	private String pid;
	private int count;
	public int getOid() {
		return oid;
	}
	
	
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
}
